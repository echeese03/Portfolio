chrome.runtime.onInstalled.addListener(function() {
    chrome.storage.local.set({"tracklist" : {}, "taglist" : new Set()});
});

chrome.runtime.onMessage.addListener((message, callback) => {
    // console.log(message);
    if (message.type === "FROM_CONTENT") {
        
        if (message.text === "init") {
            createOffscreen();
        }

        if (message.text === "listener") {
            chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
                // check for a URL in the changeInfo parameter (url is only added when it is changed)
                if (changeInfo.url) {
                    
                    // calls the inject function
                    console.log("changed to " + changeInfo.url);
                    chrome.tabs.sendMessage(tabId,
                        {type : "FROM_WORKER", text : "pageUpdate", url : changeInfo.url});
                }
            });
        }

        if (message.text === "export") {
            var blob = new Blob([message.tracklistJSON], { type: 'text/plain' });
            downloadBlob(blob, "exported_tags.txt");
        }
    }
    if (message.type === "FROM_OFFSCREEN") {
        if (message.text === "keepAlive") {
            console.log("keepAlive");
        }
    }
});

// create the offscreen document if it doesn't already exist
async function createOffscreen() {
    if (await chrome.offscreen.hasDocument?.()) return;
    await chrome.offscreen.createDocument({
        url: 'offscreen.html',
        reasons: ['BLOBS'],
        justification: 'keep service worker running',
    });
    console.log("created offscreen document");
}

// async function getCurrentTab() {
//     let queryOptions = { active: true, lastFocusedWindow: true };
//     // `tab` will either be a `tabs.Tab` instance or `undefined`.
//     let [tab] = await chrome.tabs.query(queryOptions);
//     return tab;
// }

async function downloadBlob(blob, name, destroyBlob = true) {
    // When `destroyBlob` parameter is true, the blob is transferred instantly,
    // but it's unusable in SW afterwards, which is fine as we made it only to download
    const send = async (dst, close) => {
        dst.postMessage({blob, name, close}, destroyBlob ? [await blob.arrayBuffer()] : []);
    };
    console.log("downloading");
    var tab = chrome.tabs.create({url: 'downloader.html'});
    self.addEventListener('message', function onMsg(e) {
        if (e.data === 'sendBlob') {
            self.removeEventListener('message', onMsg);
            send(e.source, !tab);
        }
    });
}