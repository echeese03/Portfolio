//
var debug = false;
//

//  Global tracklist and taglist variables.
//      Object 'tracklist' acts as a dictionary where the keys are the ids of the tracks and the values are
//      dictionaries themselves with track properties as keys (title, artist, album, tags).
//
//      Set 'taglist' stores all tags across all songs.
var tracklist = {};
var taglist = new Set();
var selectlist = new Set();
var checklist = new Set();

var baseURL = "https://music.youtube.com/";
var basePlaylistURL = "https://music.youtube.com/playlist?";
var playlistURL = document.location.href;
playlistURL = playlistURL.substring(basePlaylistURL.length, playlistURL.length);

var durationInSeconds = false;

//  Add reload tags button that adds new tracks to library when clicked
var newElement = document.createElement("yt-button-renderer");
newElement.className = "watch-button style-scope ytmusic-menu-renderer";
var buttonMenu = document.querySelector('.ytmusic-menu-renderer');
buttonMenu.appendChild(newElement);
var buttonShape = buttonMenu.querySelectorAll('yt-button-renderer')[2].querySelector('yt-button-shape');
buttonShape.innerHTML = `
    <button onclick = "loadTracks()" id = "loadTracks" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled " aria-label="Reload Tags" style="">
        <div class="cbox yt-spec-button-shape-next--button-text-content">
            <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">Reload Tags</span>
        </div>
        <yt-touch-feedback-shape style="border-radius: inherit;">
            <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
            </div>
        </yt-touch-feedback-shape>
    </button>
`;

document.querySelector("yt-checkbox-renderer").querySelector("yt-icon").click();

var observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
        if (mutation.type === "attributes" && !document.getElementById("multiAddTag")) {
            var newElement = document.createElement("yt-button-renderer");
            newElement.className = "style-scope ytmusic-menu-renderer style-scope ytmusic-menu-renderer"
            newElement.id = "multiAddTag";
            
            buttonMenu = document.getElementById("multiSelectMenu").querySelector("yt-button-renderer").parentElement;
            buttonMenu.appendChild(newElement);
            var buttonShape = buttonMenu.querySelectorAll('yt-button-shape')[2];
            buttonShape.innerHTML = `
            <button onclick="openMultiModal('modal-MULTI')" class="yt-spec-button-shape-next yt-spec-button-shape-next--text yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-only-default" aria-label="Add Tag" style="">
                <div class="yt-spec-button-shape-next__icon" aria-hidden="true">
                    <yt-icon style="width: 24px; height: 24px;">
                    </yt-icon>
                </div>
                <yt-touch-feedback-shape style="border-radius: inherit;">
                    <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response" aria-hidden="true">
                        <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                        <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                    </div>
                </yt-touch-feedback-shape>
            </button>
            `;
            var icon = buttonMenu.querySelectorAll("yt-icon")[2];
            icon.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="#F9E79F" class="bi bi-hash" viewBox="0 0 16 16">
                <path
                    d="M8.39 12.648a1.32 1.32 0 0 0-.015.18c0 .305.21.508.5.508.266 0 .492-.172.555-.477l.554-2.703h1.204c.421 0 .617-.234.617-.547 0-.312-.188-.53-.617-.53h-.985l.516-2.524h1.265c.43 0 .618-.227.618-.547 0-.313-.188-.524-.618-.524h-1.046l.476-2.304a1.06 1.06 0 0 0 .016-.164.51.51 0 0 0-.516-.516.54.54 0 0 0-.539.43l-.523 2.554H7.617l.477-2.304c.008-.04.015-.118.015-.164a.512.512 0 0 0-.523-.516.539.539 0 0 0-.531.43L6.53 5.484H5.414c-.43 0-.617.22-.617.532 0 .312.187.539.617.539h.906l-.515 2.523H4.609c-.421 0-.609.219-.609.531 0 .313.188.547.61.547h.976l-.516 2.492c-.008.04-.015.125-.015.18 0 .305.21.508.5.508.265 0 .492-.172.554-.477l.555-2.703h2.242l-.515 2.492zm-1-6.109h2.266l-.515 2.563H6.859l.532-2.563z"
                ></path>
            </svg>
            `
            var tooltip = buttonMenu.querySelectorAll('tp-yt-paper-tooltip')[2];
            tooltip.removeAttribute("disable-upgrade");
            tooltip.innerHTML = `
            <div id="tooltip" class="style-scope tp-yt-paper-tooltip hidden" style-target="tooltip">
                Add Tag
            </div>
            `
            buttonMenu.style="margin-right: 0;";
            document.querySelector("ytmusic-dialog").querySelector("yt-formatted-string").parentElement.style="margin: 0 40px 0 10px;";
        }
    });
});

function addObserverIfDesiredNodeAvailable() {
    var multiSelectMenu = document.querySelector("ytmusic-dialog");
    console.log(multiSelectMenu);
    if(!multiSelectMenu) {
        //The node we need does not exist yet.
        //Wait 500ms and try again
        window.setTimeout(addObserverIfDesiredNodeAvailable,500);
        return;
    }
    var config = {attributes: true, attributeFilter: ["style"]};
    observer.observe(multiSelectMenu,config);
}
addObserverIfDesiredNodeAvailable();
document.querySelector("yt-checkbox-renderer").querySelector("yt-icon").click();


newElement = document.createElement("div");
let modalID = "modal-MULTI";
newElement.innerHTML=`
<div id="${modalID}" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeMultiModal(\'${modalID}\')">&times;</span>
        <h1 style="overflow: hidden; color: #F9E79F;">Tag Multi-Add</h1><br>
        <h2 style="color: #F9E79F;">Add</h2>
        <div id="addTagContainer-${modalID}" class = "addTagContainer-container">
        </div>

        <br>
        <h2 style="color: #F9E79F;">to the following tracks:</h2>
        <div id="checkedTracks-${modalID}" class = "checkedTracks">
        
        </div>
    
    </div>
</div>
`
document.body.appendChild(newElement);

//  Automatically load songs
window.postMessage(
    {type : "FROM_PAGE", text : "load"}, "*");

//  Autosave on exiting page DOESNT WORK
//
// window.addEventListener("beforeunload", save());

// function save() {
//     if (debug) console.log("saving");
//     var jsonString = exportTags(tracklist);
//     window.postMessage(
//         {type : "FROM_PAGE", text : "save", tracklistJSON : jsonString}, "*");
//     return null;
// }

//  Listen for load signal from content.js
window.addEventListener("message", (event) => {
    // We only accept messages from ourselves
    if (event.source !== window) {
        return;
    }

    if (event.data.type && (event.data.type === "FROM_CONTENT")) {
        if (debug) console.log("Content script received: " + event.data.text);

        if (event.data.text === "loaded") {
            tracklist, taglist = importTags(event.data.tracklistJSON);
            refreshTagDisplay();
        }
    }
}, false);


//  Adds a track to global tracklist. Can input preset tags.
//  ADD FUNCTION WHERE ARTIST IS DETERMINED BY ARTIST URL TO COMBINE DIFFERENT NAMES TO SAME ARTIST (replace album?)
function addTrack(id, title, artist, album, url, tags = new Set()) {
    if (id in tracklist) {
        if (debug) console.log("Track \"" + title + "\" already in tracklist; failed to add.");
        return false;
    }
    tracklist[id] = { "URL": url, "Title": title, "Artist": artist, "Album": album, "Tags": tags }
    addTag(id, artist);
    tags.forEach(taglist.add, taglist);
    if (debug) console.log("Added \"" + id + "\" and refreshed taglist.");
    return true;
}

//  Removes a track from global tracklist.
function removeTrack(id) {
    if (id in tracklist) {
        tags = new Set(tracklist[id]["Tags"]);
        delete tracklist[id];
        tags.forEach(element => {
            refreshTaglist(element);
        });
        return true;
    }
    if (debug) console.log("Track \"" + id + "\" does not exist in tracklist; failed to remove.")
    return false;
}

//  Adds specified tag to track and global taglist.
function addTag(id, tag) {
    tag = processString(tag);
    if (id in tracklist) {
        track = tracklist[id];
        tags = track["Tags"];
        if (tags.has(tag)) {
            if (debug) console.log("Track \"" + id + "\" already has tag \"" + tag + "\"; failed to add tag.");
            return false;
        }
        if (tag == "") {
            if (debug) console.log("Tag is empty.")
            return false;
        }
        tags.add(tag);
        taglist.add(tag);
        if (debug) console.log("Added tag \"" + tag + "\" to track.");
        return true;
    }
    if (debug) console.log("Track \"" + id + "\" does not exist; failed to add tag \"" + tag + "\".");
    return false;
}

//  Removes specified tag from track and runs refreshTaglist
function removeTag(id, tag) {
    if (id in tracklist) {
        track = tracklist[id];
        tags = track["Tags"];
        if (tags.has(tag)) {
            tags.delete(tag);
            if (debug) console.log("Removed \"" + tag + "\" from track.");
            refreshTaglist(tag);
            return true;
        }
        if (debug) console.log("Track \"" + id + "\" does not have tag \"" + tag + "\"; failed to remove tag.");
        return false;
    }
    if (debug) console.log("Track \"" + id + "\" does not exist; failed to remove tag \"" + tag + "\".");
    return false;
}

//  Checks global tracklist for remaining tracks with specified tag. If there are no more tracks
//  with specified tag, the tag is removed from global taglist.
function refreshTaglist(tag) {
    i = 0;
    for (let id in tracklist) {
        element = tracklist[id];
        i += element["Tags"].has(tag);
    }
    if (i > 0) {
        if (debug) console.log("There are still " + i + " tracks with tag \"" + tag + "\".");
        return false;
    }
    taglist.delete(tag);
    if (debug) console.log("\"" + tag + "\" was removed from global taglist because there are no more tracks with \"" + tag + "\".");
    return true;
}

//  Returns set of all track objects with the specified tags in 'tagset' parameter
function getTracksWithTag(tagset) {
    var tracksWithTag = new Set();
    var keys = Object.keys(tracklist);
    for (let i = 0; i < keys.length; i++) {
        var track = tracklist[keys[i]];
        // var trackKeys = Object.keys(track);
        isValid = true;
        tagset.forEach(tag => {
            if (isValid && !track["Tags"].has(tag)) {
                isValid = false;
            }
        });
        if (isValid) {
            tracksWithTag.add(track);
        }
    }
    return tracksWithTag;
}

function processString(str) {
    str = str.trim();
    str = str.replaceAll("\"", "");
    str = str.replaceAll("\'", "");
    str = str.replaceAll("_", " ");
    return str.replaceAll(".mp3", "");
}

// function convertDurationtoSeconds(duration) {
//     const hasHours = duration.split(':').length - 1 === 2;
//     if (hasHours) {
//         const [hours, minutes, seconds] = duration.split(':');
//         return 360 * Number(hours) + 60 + Number(minutes) + Number(seconds);
//     } else {
//         const [minutes, seconds] = duration.split(':');
//         return 60 * Number(minutes) + Number(seconds);
//     }
// };

function loadTracks() {
    var playlistTrackContainers = document.querySelectorAll('#header + #contents > ytmusic-playlist-shelf-renderer ytmusic-responsive-list-item-renderer');
    for(var i = 0; i < playlistTrackContainers.length ; i++) { 
        var trackContainer = playlistTrackContainers[i];
        var id = "";
        var url = "";
    
        var title = trackContainer.querySelector('.title-column');
        if(title !== null) {
            var atag = title.querySelector("a");
            if (atag !== null) {
                url = atag.href;
                url = url.substring(baseURL.length,url.length-playlistURL.length-1);
            }
            title = processString(title.textContent);
        } else return;
    
        var artist = trackContainer.querySelector('.secondary-flex-columns > yt-formatted-string:first-child');
        if(artist !== null) {
            artist = processString(artist.textContent);
        } else return;
    
        //  Finds duration of track
        // var duration = trackContainer.children[trackContainer.children.length - 1];
        // if(duration !== null) {
        //     duration = processString(duration.textContent);
        //     if (durationInSeconds) {
        //         duration = convertDurationtoSeconds(duration);
        //     }
        // }
    
        var album = trackContainer.querySelector('.secondary-flex-columns > yt-formatted-string:nth-child(2)');
        if(album !== null)
            album = processString(album.textContent);
        
        id = title + "_-_" + artist;
        temp = addTrack(id, title, artist, album, url);
        track = tracklist[id];
    }
    refreshTagDisplay();
}

function refreshTagDisplay() {
    var tracksToDisplay = getTracksWithTag(selectlist);
    var playlistTrackContainers = document.querySelectorAll('#header + #contents > ytmusic-playlist-shelf-renderer ytmusic-responsive-list-item-renderer');
    for(var i = 0; i < playlistTrackContainers.length ; i++) { 
        var trackContainer = playlistTrackContainers[i];
        var url = "";
        var id = "";
    
        var title = trackContainer.querySelector('.title-column');
        if(title !== null) {
            var atag = title.querySelector("a");
            if (atag !== null) {
                url = atag.href;
                url = url.substring(baseURL.length,url.length-playlistURL.length-1);
            } 
            title = processString(title.textContent);
        } else return;
    
        var artist = trackContainer.querySelector('.secondary-flex-columns > yt-formatted-string:first-child');
        if(artist !== null) {
            artist = processString(artist.textContent);
        } else return;
    
        var album = trackContainer.querySelector('.secondary-flex-columns > yt-formatted-string:nth-child(2)');
        if(album !== null)
            album = processString(album.textContent);
        
        id = title + "_-_" + artist;

        if (!tracklist[id]) {
            continue;
        }

        track = tracklist[id];
        tags = track["Tags"];

        var buttonMenu = trackContainer.querySelector('.ytmusic-menu-renderer');

        //  Clear existing tag buttons
        temp = buttonMenu.children.length
        for (j = 5; j < temp; j++) {
            buttonMenu.removeChild(buttonMenu.lastChild);
            if (debug) console.log("Cleared existing tag buttons for \"" + id + "\".");
        }

        //Show AND yt-select wanted tracks, while hiding unwanted tracks
        if (selectlist.size > 0) {
            if (!tracksToDisplay.has(track)) {
                if (trackContainer.hasAttribute("is-checked")) {
                    trackContainer.querySelector("yt-checkbox-renderer").querySelector("yt-icon").click();
                }
                trackContainer.setAttribute('style',"display: none;");
            } else {
                trackContainer.setAttribute('style',"");
                if (!trackContainer.hasAttribute("is-checked")) {
                    trackContainer.querySelector("yt-checkbox-renderer").querySelector("yt-icon").click();
                }
            }
        } else {
            if (trackContainer.hasAttribute("is-checked")) {
                trackContainer.querySelector("yt-checkbox-renderer").querySelector("yt-icon").click();
            }
            trackContainer.setAttribute('style',"");
        }


        if (trackContainer.style != "display: none") {
            var remainingTags = new Set(tags);
            let k = 0;
            selectlist.forEach(tag => {
                if (tag != artist && k < 3) {
                    remainingTags.delete(tag);
                    k += 1;
                    var newElement = document.createElement("yt-button-renderer");
                    newElement.className = "watch-button style-scope ytmusic-menu-renderer"
                    newElement.id = "tag-" + url + "_" + tag;
                    newElement.style = "visibility: visible !important;"
                    
                    buttonMenu.appendChild(newElement);
                    var buttonShape = buttonMenu.querySelectorAll('yt-button-renderer')[k-1].querySelector('yt-button-shape');
                    var buttonType = "filled";
                    buttonShape.innerHTML = `
                        <button onclick="selectTag('${tag}')" class="yt-spec-button-shape-next yt-spec-button-shape-next--${buttonType} yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButton${buttonType}" aria-label="${tag}" style="">
                            <div class="cbox yt-spec-button-shape-next--button-text-content">
                                <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">${tag}</span>
                            </div>
                            <yt-touch-feedback-shape style="border-radius: inherit;">
                                <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                                    <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                                    <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                                </div>
                            </yt-touch-feedback-shape>
                        </button>
                    `;
                    if (debug) console.log("Added button \"" + url + "_" + tag + "\".");
                }
            });

            remainingTags.forEach(tag => {
                if (tag != artist && k < 3) {
                    k += 1;
                    var newElement = document.createElement("yt-button-renderer");
                    newElement.className = "watch-button style-scope ytmusic-menu-renderer"
                    newElement.id = "tag-" + url + "_" + tag;
                    newElement.style = "visibility: visible !important;"
                    
                    buttonMenu.appendChild(newElement);
                    var buttonShape = buttonMenu.querySelectorAll('yt-button-renderer')[k-1].querySelector('yt-button-shape');
                    var buttonType = "outline";
                    buttonShape.innerHTML = `
                        <button onclick="selectTag('${tag}')" class="yt-spec-button-shape-next yt-spec-button-shape-next--${buttonType} yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButton${buttonType}" aria-label="${tag}" style="">
                            <div class="cbox yt-spec-button-shape-next--button-text-content">
                                <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">${tag}</span>
                            </div>
                            <yt-touch-feedback-shape style="border-radius: inherit;">
                                <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                                    <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                                    <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                                </div>
                            </yt-touch-feedback-shape>
                        </button>
                    `;
                    if (debug) console.log("Added button \"" + url + "_" + tag + "\".");
                }
            });

            var newElement = document.createElement("yt-button-renderer");
            newElement.className = "watch-button style-scope ytmusic-menu-renderer"
            newElement.id = "edit-" + url;
            newElement.style = "visibility: visible !important;"
            
            buttonMenu.appendChild(newElement);
            temp = buttonMenu.querySelectorAll('yt-button-renderer');
            var buttonShape = temp[temp.length-1].querySelector('yt-button-shape');
            var modalID = "modal-" + url;

            buttonShape.innerHTML = `
                <button onclick = "openEditModal(\'${id}\', \'${modalID}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled " aria-label="Edit Tags" style="">
                    <div class="cbox yt-spec-button-shape-next--button-text-content"
                        <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">EDIT</span>
                    </div>
                    <yt-touch-feedback-shape style="border-radius: inherit;">
                        <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response" aria-hidden="true">
                            <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                            <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                        </div>
                    </yt-touch-feedback-shape>
                </button>
                <div id="${modalID}" class="modal">
                    <div class="modal-content">
                        <span class="close" onclick="closeEditModal(\'${id}\', \'${modalID}\')">&times;</span>
                        <h1 style="overflow: hidden; color: #F9E79F;">${title}</h1><br>
                        <h3 style="overflow: hidden; color: #F9E79F;">${artist}</h3><br>
                        
                        <div id="addTagContainer-${modalID}" class = "addTagContainer-container">
                        </div>
                        
                        <br>
                        
                        <div id="tagContainer-${modalID}" class="tagContainer-container">
                        </div>
                    
                    </div>
                </div>
            `;
            if (debug) console.log("Added EDIT (tags) button for track \"" + id + "\".");
        }

    }
}

function selectTag(tag) {
    if (selectlist.has(tag)) {
        selectlist.delete(tag);
    } else {
        selectlist.add(tag);
    }
    refreshTagDisplay();
}

function modalAddTag(id, modalID) {
    var inputID = document.getElementById("addTag-" + modalID);
    tag = inputID.value;
    addTag(id, tag);
    refreshEditModal(id, modalID);
    inputID.value = "";
}

function modalRemoveTag(id, modalID, tag) {
    var track = tracklist[id],
        artist = track["Artist"];
    if (tag != artist) {
        removeTag(id, tag);
        refreshEditModal(id, modalID);
    }
}

function refreshEditModal(id, modalID) {
    var tagContainer = document.getElementById("tagContainer-" + modalID);
    tagContainer.innerHTML = "";
    if (debug) console.log("Cleared tags.");
    
    var track = tracklist[id],
        title = track["Title"],
        artist = track["Artist"];
    
    //  Add tag buttons for track in modal
    track = tracklist[id];
    tags = track["Tags"];
    var i = 0;
    tags.forEach(tag => {
        if (i < 20) {
            i++;
            var newElement = document.createElement("yt-button-renderer");
            newElement.className = "watch-button style-scope ytmusic-menu-renderer tag-item"
            tagContainer.appendChild(newElement);
            var buttonShape = tagContainer.querySelectorAll('yt-button-renderer')[i-1].querySelector('yt-button-shape');
            buttonShape.innerHTML = `
                <button onclick="modalRemoveTag(\'${id}\', \'${modalID}'\, \'${tag}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled " aria-label="${tag}" style="">
                    <div class="cbox yt-spec-button-shape-next--button-text-content">
                        <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">${tag}</span>
                    </div>
                    <yt-touch-feedback-shape style="border-radius: inherit;">
                        <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                            <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                            <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                        </div>
                    </yt-touch-feedback-shape>
                </button>
            `;
        }   
    });

    var addTagContainer = document.getElementById("addTagContainer-" + modalID);
    addTagContainer.innerHTML = `
        <iron-input slot="input" class="addTag-item input-element style-scope tp-yt-paper-input" maxlength="20">
            <input onclick="this.select()" id="addTag-${modalID}" class="addTag-item style-scope tp-yt-paper-input" maxlength="20" type="text" value="" autocomplete="off" placeholder="New tag name">
        </iron-input>
        <button id="addTagButton-${modalID}" onclick = "modalAddTag(\'${id}\', \'${modalID}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled " aria-label="Add Tag">
            <div class="cbox yt-spec-button-shape-next--button-text-content"
                <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">ADD</span>
            </div>
            <yt-touch-feedback-shape style="border-radius: inherit;">
                <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response" aria-hidden="true">
                    <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                    <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                </div>
            </yt-touch-feedback-shape>
        </button>
    `;
    var input = document.getElementById(`addTag-${modalID}`);

    // Execute a function when the user presses a key on the keyboard
    input.addEventListener("keydown", function(event) {
    // If the user presses the "Enter" key on the keyboard
    if (event.key === "Enter") {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        document.getElementById(`addTagButton-${modalID}`).click();
        document.getElementById(`addTag-${modalID}`).focus();
    } else if (event.key === "Escape") {
        event.preventDefault();
        closeEditModal(id, modalID);
    }
    });
}

// IN PROGRESS
function refreshMultiModal(modalID) {
    var playlistTrackContainers = document.querySelectorAll('#header + #contents > ytmusic-playlist-shelf-renderer ytmusic-responsive-list-item-renderer');
    checklist = new Set();
    for(var i = 0; i < playlistTrackContainers.length ; i++) {
        var trackContainer = playlistTrackContainers[i];
        if (trackContainer.hasAttribute("is-checked")) {
            checklist.add(track);
            printWrap(checklist);
        }
    }
    var checkedContainer = document.getElementById("checkedTracks-" + modalID);
    checkedContainer.innerHTML="";
    printWrap("cleared checked tracks container");
    var arr = new Set();
    htmlToAdd = "<ul style='overflow: hidden; word-wrap: none;'>";
    checklist.forEach(track => {
        title = track.Title;
        artist = track.Artist;
        arr.add(track.id);
        htmlToAdd += `
            <li style="overflow: hidden;">${title} - ${artist}</li>
        `
    });
    
    htmlToAdd += "</ul>";
    checkedContainer.innerHTML = htmlToAdd;


    var addTagContainer = document.getElementById("addTagContainer-" + modalID);
    addTagContainer.innerHTML = `
        <iron-input slot="input" class="addTag-item input-element style-scope tp-yt-paper-input" maxlength="20">
            <input onclick="this.select()" id="addTag-${modalID}" class="addTag-item style-scope tp-yt-paper-input" maxlength="20" type="text" value="" autocomplete="off" placeholder="New tag name">
        </iron-input>
        <button id="addTagButton-${modalID}" onclick = "multiAddTag(\'${modalID}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled " aria-label="Add Tag">
            <div class="cbox yt-spec-button-shape-next--button-text-content"
                <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">ADD</span>
            </div>
            <yt-touch-feedback-shape style="border-radius: inherit;">
                <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response" aria-hidden="true">
                    <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                    <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                </div>
            </yt-touch-feedback-shape>
        </button>
    `;
    var input = document.getElementById(`addTag-${modalID}`);

    // Execute a function when the user presses a key on the keyboard
    input.addEventListener("keydown", function(event) {
    // If the user presses the "Enter" key on the keyboard
    if (event.key === "Enter") {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        document.getElementById(`addTagButton-${modalID}`).click();
        document.getElementById(`addTag-${modalID}`).focus();
    } else if (event.key === "Escape") {
        event.preventDefault();
        closeEditModal(id, modalID);
    }
    });
}

function multiAddTag(modalID) {
    var inputID = document.getElementById("addTag-" + modalID);
    tag = inputID.value;
    
    checklist.forEach(track => {
        addTag(track.id, tag);
    });

    closeMultiModal(modalID);
    inputID.value = "";
}

function openMultiModal(modalID) {
    refreshMultiModal(modalID);
    document.getElementById(modalID).style.display = "block";
    printWrap("Opened modal \"" + modalID + "\"");
}

function closeMultiModal(modalID) {
    var tagContainer = document.getElementById("checkedTracks-" + modalID);
    tagContainer.innerHTML = "";
    document.getElementById(modalID).style.display = "none";
    refreshTagDisplay();
    if (debug) console.log("Closed modal \"" + modalID + "\"");
}

function openEditModal(id, modalID) {
    refreshEditModal(id, modalID);
    document.getElementById(modalID).style.display = "block";
    printWrap("Opened modal \"" + modalID + "\"");
}

function closeEditModal(id, modalID) {
    var tagContainer = document.getElementById("tagContainer-" + modalID);
    tagContainer.innerHTML = "";
    document.getElementById(modalID).style.display = "none";
    refreshTagDisplay();
    if (debug) console.log("Closed modal \"" + modalID + "\"");
}

function importTags(trackJSON) {
    taglist = new Set();
    tracklist = JSON.parse(trackJSON);
    var keys = Object.keys(tracklist)
    for (i = 0; i < keys.length; i++) {
        var track = tracklist[keys[i]];
        tags = new Set(track["Tags"]);
        track["Tags"] = tags;
        tags.forEach(taglist.add, taglist);
    }
    return (tracklist, taglist);
}

function printWrap(content) {
    if (debug) console.log(content);
}