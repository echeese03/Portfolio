//
var debug = false;
//

//  Global tracklist and taglist variables.
//      Object 'tracklist' acts as a dictionary where the keys are the ids of the tracks and the values are
//      dictionaries themselves with track properties as keys (title, artist, album, tags).
//
//      Set 'taglist' stores all tags across all songs.
var tracklist = {};
var taglist = new Set();
var selectlist = new Set();
var skiplist = new Set();

//  Queue!!
var queueList = [];
var selectableTags = new Set();
var nextClicked = false;
var previousSong = "";

var baseURL = "https://music.youtube.com/";
var basePlayerURL = "https://music.youtube.com/watch?";

//  Automatically load songs
window.postMessage(
    {type : "FROM_PAGE", text : "load"}, "*");

//  Listen for load signal from content.js
window.addEventListener("message", (event) => {
    // We only accept messages from ourselves
    if (event.source !== window) {
        return;
    }

    if (event.data.type && (event.data.type === "FROM_CONTENT")) {
        if (debug) console.log("Content script received: " + event.data.text);

        if (event.data.text === "loaded") {
            tracklist, taglist = importTags(event.data.tracklistJSON);
            // refreshTagDisplay();
        }

        if (event.data.text === "skipped") {
            reInit();
        }

    }
}, false);

var initialize = setInterval(function () {
    var playing = document.getElementById("play-pause-button");
    if (playing.title === "Pause") {
        init();
    }
}, 1000);

async function reInit() {
    let promise = new Promise((resolve) => {
        const checkId = () => {
          id = currentSong();
          if (id !== previousSong) {
            resolve(true);
          } else {
            setTimeout(checkId, 1000); // wait 1 second before checking again
          }
        }
        checkId();
    });
    let update = await promise;
    if (update) {
        init();
    } else {
        if (debug) console.log("could not reinit");
    }
    
}

function init() {
    if(initialize) {
        clearInterval(initialize);
        initialize = null;
    }
    refreshQueue();
    refreshPlayer();
}

function next() {
    var nextButton = document.getElementsByClassName("next-button")[0];
    if (nextButton) {
        if (!nextClicked) {
            nextClicked = true;
            nextButton.click();
            reInit();
            refreshPlayer();
        } else {
            refreshPlayer();
        }
    }
}

//  Add tags and select button to player
async function refreshPlayer() {
    var id = "";
    var track = undefined;
    
    var tracksToPlay = getTracksWithTag(selectlist);
    
    //var tracksToSkip = getTracksWithTag(skiplist);
    let promise = new Promise((resolve) => {
        const checkId = () => {
          id = currentSong();
          if (tracklist[id] !== undefined) {
            resolve(tracklist[id]);
          } else {
            setTimeout(checkId, 1000); // wait 1 second before checking again
          }
        }
        checkId();
    });

    track = await promise;

    tags = track["Tags"];
    url = track["URL"];

    if (debug) console.log(track);
    if (debug) console.log(tracksToPlay)
    if (debug) console.log(tracksToPlay.has(track));

    //  Skip!!
    if (selectlist.size > 0 && !tracksToPlay.has(track)) {     //!tracksToPlay.has(track) || tracksToSkip.has(track)
        setTimeout(next(),100);
    } else {
        nextClicked = false;
    }
    if (id != previousSong) {
        if (!tracksToPlay.has(track)) {
            nextClicked = false;
        }
        previousSong = id;
    }

    var buttonMenu = document.querySelector('.middle-controls-buttons').querySelector('ytmusic-menu-renderer');
    //  Clear existing tag buttons
    temp = buttonMenu.children.length
    for (j = 4; j < temp; j++) {
        buttonMenu.removeChild(buttonMenu.lastChild);
        if (debug) console.log("Cleared existing tag buttons for \"" + id + "\".");
    }

    var modalExists = document.getElementById("modal-player-div");
    if (modalExists) {
        modalExists.remove();
    }

    k = 0;
    tags.forEach(tag => {
        if (k < 3) {
            k += 1;
            var newElement = document.createElement("yt-button-renderer");
            newElement.className = "watch-button style-scope ytmusic-menu-renderer"
            newElement.style = "padding-right: 5px;";
            newElement.id = "tag-" + url + "_" + tag;
            
            buttonMenu.appendChild(newElement);
            var buttonShape = buttonMenu.querySelectorAll('yt-button-renderer')[k-1].querySelector('yt-button-shape');
            var buttonType = "outline";
            if (selectlist.has(tag)) {
                buttonType = "filled";
            }
            buttonShape.innerHTML = `
                <button onclick="selectTag('${tag}')" class="yt-spec-button-shape-next yt-spec-button-shape-next--${buttonType} yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading " aria-label="${tag}" style="">
                    <div class="cbox yt-spec-button-shape-next--button-text-content">
                        <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">${tag}</span>
                    </div>
                    <yt-touch-feedback-shape style="border-radius: inherit;">
                        <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                            <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                            <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                        </div>
                    </yt-touch-feedback-shape>
                </button>
            `;
            if (debug) console.log("Added button \"" + url + "_" + tag + "\".");
        }
    });

    var newElement = document.createElement("yt-button-renderer");
    newElement.className = "watch-button style-scope ytmusic-menu-renderer"
    newElement.id = "select-player";
    
    buttonMenu.appendChild(newElement);
    temp = buttonMenu.querySelectorAll('yt-button-renderer');
    var buttonShape = temp[temp.length-1].querySelector('yt-button-shape');
    var modalID = "modal-player";

    buttonShape.innerHTML = `
        <button onclick = "openPlayerModal(\'${id}\', \'${modalID}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--outline yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading " aria-label="Select Tags" style="">
            <div class="cbox yt-spec-button-shape-next--button-text-content"
                <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">SELECT</span>
            </div>
            <yt-touch-feedback-shape style="border-radius: inherit;">
                <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response" aria-hidden="true">
                    <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                    <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                </div>
            </yt-touch-feedback-shape>
        </button>
    `;
    
    modal = document.createElement('div');
    modal.id = "modal-player-div";
    document.getElementById("player-page").appendChild(modal);
    modal = document.getElementById("modal-player-div");
    modal.innerHTML = `
        <div id="${modalID}" class="modal">
            <div class="modal-content">
                <span class="close" onclick="closePlayerModal(\'${modalID}\')">&times;</span>
                <h1 style="overflow: hidden;">Playback Options</h1><br>
                
                <div id="addFilterTagContainer-${modalID}" class = "addTagContainer-container">
                </div>
                
                <br>
                
                <div id="filterTagContainer-${modalID}" class="tagContainer-container">
                </div>

                <div id="addSkipTagContainer-${modalID}" class = "addTagContainer-container">
                </div>

                <div id="skipTagContainer-${modalID}" class="tagContainer-container">
                </div>

            
            </div>
        </div>
    `;

    if (debug) console.log("Added SELECT (tags) button.");
}

function openPlayerModal(id, modalID) {
    //Refresh Player Modal
    refreshPlayerModal(modalID);
    document.getElementById(modalID).style.display = "block";
    if (debug) console.log("Opened modal \"" + modalID + "\"");
}

function closePlayerModal(modalID) {
    var tagContainer = document.getElementById("filterTagContainer-" + modalID);
    tagContainer.innerHTML = "";
    // tagContainer = document.getElementById("skipTagContainer-" + modalID);
    // tagContainer.innerHTML = "";
    document.getElementById(modalID).style.display = "none";
    //Refresh playerbar tag display
    // refreshTagDisplay();
    refreshQueue();
    refreshPlayer();
    if (debug) console.log("Closed modal \"" + modalID + "\"");
}

function refreshPlayerModal(modalID) {
    if (debug) console.log("refreshing player modal");
    var filterTagContainer = document.getElementById("filterTagContainer-" + modalID);
    filterTagContainer.innerHTML = "";
    if (debug) console.log("Cleared tags.");
    
    tags = selectableTags;
    var i = 0;
    tags.forEach(tag => {
        i++;
        var newElement = document.createElement("yt-button-renderer");
        newElement.className = "watch-button style-scope ytmusic-menu-renderer tag-item"
        filterTagContainer.appendChild(newElement);
        var buttonShape = filterTagContainer.querySelectorAll('yt-button-renderer')[i-1].querySelector('yt-button-shape');
        var buttonType = "outline";
        if (selectlist.has(tag)) {
            buttonType = "filled";
        }
        buttonShape.innerHTML = `
            <button onclick="modalSelectTag(\'${tag}\', \'${modalID}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--${buttonType} yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading " aria-label="${tag}" style="">
                <div class="cbox yt-spec-button-shape-next--button-text-content">
                    <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">${tag}</span>
                </div>
                <yt-touch-feedback-shape style="border-radius: inherit;">
                    <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                        <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                        <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                    </div>
                </yt-touch-feedback-shape>
            </button>
        `;
    });

    var addFilterTagContainer = document.getElementById("addFilterTagContainer-" + modalID);
    addFilterTagContainer.innerHTML = `
        <iron-input slot="input" class="addTag-item input-element style-scope tp-yt-paper-input" maxlength="20">
            <input onclick="this.select()" id="addFilterTag-${modalID}" class="addTag-item style-scope tp-yt-paper-input" maxlength="20" type="text" value="" autocomplete="off" placeholder="New tag name">
        </iron-input>
        <button id="addFilterTagButton-${modalID}" onclick = "addFilterTag(\'${modalID}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--outline yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading " aria-label="Add Tag">
            <div class="cbox yt-spec-button-shape-next--button-text-content"
                <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">SELECT</span>
            </div>
            <yt-touch-feedback-shape style="border-radius: inherit;">
                <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response" aria-hidden="true">
                    <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                    <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                </div>
            </yt-touch-feedback-shape>
        </button>
    `;
    var input = document.getElementById(`addFilterTag-${modalID}`);

    // Execute a function when the user presses a key on the keyboard
    input.addEventListener("keypress", function(event) {
    // If the user presses the "Enter" key on the keyboard
    if (event.key === "Enter") {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        document.getElementById(`addFilterTagButton-${modalID}`).click();
        document.getElementById(`addFilterTag-${modalID}`).focus();
    }
    });
}

function addFilterTag(modalID) {
    var inputID = document.getElementById("addFilterTag-" + modalID);
    tag = inputID.value;
    if(selectableTags.has(tag)) {
        modalSelectTag(tag, modalID);
        inputID.value = "";
    } else {
        alert("Tag does not exist in queue; cannot select tag.");
    }
}

function refreshQueue() {
    queueList = [];
    selectableTags = new Set();
    var queue = document.querySelector(".modular").querySelector("#contents");
    var queueTrackContainers = queue.children;
    var tracksToDisplay = getTracksWithTag(selectlist);

    for(var i = 0; i < queueTrackContainers.length; i++) {
        var trackBigContainer = queueTrackContainers[i]
        var trackContainer = trackBigContainer;
        var hasVideo = trackBigContainer.querySelector("#primary-renderer");
        if (hasVideo) {
            trackContainer = hasVideo;
        }

        var id = "",
            title = "";
            artist = "";
    
        var songInfo = trackContainer.querySelector('.song-info');
        if(songInfo !== null) {
            var info = songInfo.querySelectorAll('yt-formatted-string');
            title = processString(info[0].textContent);
            artist = processString(info[1].textContent);
        } else return;
        id = title + "_-_" + artist;
        
        queueList.push(id);
        track = tracklist[id];

        if (selectlist.size > 0) {
            if (!tracksToDisplay.has(track)) {
                if (trackBigContainer.tagName == "YTMUSIC-PLAYER-QUEUE-ITEM") {
                    trackBigContainer.setAttribute("style", "--ytmusic-player-queue-item-thumbnail-size:32px; opacity: 0.5; mix-blend-mode: luminosity;");
                } else {
                trackBigContainer.setAttribute("style", "opacity: 0.5; mix-blend-mode: luminosity;");
                }
            } else {
                if (trackBigContainer.tagName == "YTMUSIC-PLAYER-QUEUE-ITEM") {
                    trackBigContainer.setAttribute("style", "--ytmusic-player-queue-item-thumbnail-size:32px;");
                } else {
                    trackBigContainer.setAttribute("style", "");;
                }
            }
        } else {
            if (trackBigContainer.tagName == "YTMUSIC-PLAYER-QUEUE-ITEM") {
                trackBigContainer.setAttribute("style", "--ytmusic-player-queue-item-thumbnail-size:32px;");
            } else {
                trackBigContainer.setAttribute("style", "");;
            }
        }

        var tags = track["Tags"];
        tags.forEach(tag => {
            selectableTags.add(tag);
        });
    }
}

function currentSong() {
    var currentInfo = document.querySelector(".content-info-wrapper").querySelectorAll("yt-formatted-string");
    var title = processString(currentInfo[0].textContent);
    var artist = processString(currentInfo[1].title.split("•")[0]);
    var id = title + "_-_" + artist;
    return id;
}

//  Returns set of all track objects with the specified tags in 'tagset' parameter
function getTracksWithTag(tagset) {
    var tracksWithTag = new Set();
    var keys = Object.keys(tracklist);
    for (let i = 0; i < keys.length; i++) {
        var track = tracklist[keys[i]];
        // var trackKeys = Object.keys(track);
        isValid = true;
        tagset.forEach(tag => {
            if (isValid && !track["Tags"].has(tag)) {
                isValid = false;
            }
        });
        if (isValid) {
            tracksWithTag.add(track);
        }
    }
    return tracksWithTag;
}

function processString(str) {
    str = str.trim();
    str = str.replaceAll("\"", "");
    str = str.replaceAll("\'", "");
    str = str.replaceAll("_", " ");
    return str.replaceAll(".mp3", "");
}

// function convertDurationtoSeconds(duration) {
//     const hasHours = duration.split(':').length - 1 === 2;
//     if (hasHours) {
//         const [hours, minutes, seconds] = duration.split(':');
//         return 360 * Number(hours) + 60 + Number(minutes) + Number(seconds);
//     } else {
//         const [minutes, seconds] = duration.split(':');
//         return 60 * Number(minutes) + Number(seconds);
//     }
// };

function selectTag(tag) {
    if (selectlist.has(tag)) {
        selectlist.delete(tag);
    } else {
        selectlist.add(tag);
    }
    refreshQueue();
    refreshPlayer();
}

function modalSelectTag(tag, modalID) {
    if (selectlist.has(tag)) {
        selectlist.delete(tag);
    } else {
        selectlist.add(tag);
    }
    refreshPlayerModal(modalID);
}

function importTags(trackJSON) {
    taglist = new Set();
    tracklist = JSON.parse(trackJSON);
    var keys = Object.keys(tracklist)
    for (i = 0; i < keys.length; i++) {
        var track = tracklist[keys[i]];
        tags = new Set(track["Tags"]);
        track["Tags"] = tags;
        tags.forEach(taglist.add, taglist);
    }
    return (tracklist, taglist);
}   