//
var debug = false;
//

var tracklist = {};
var taglist = new Set();

var playlistURL = "https://music.youtube.com/playlist?";
var libraryURL = "https://music.youtube.com/library";
var songsURL = "https://music.youtube.com/library/songs"
var playerURL = "https://music.youtube.com/watch?";

var tabURL = location.href;
var currentTabURL = tabURL;

navbarInit();
attachListener();
reInit();

function reInit() {
    chrome.runtime.sendMessage({ type: 'FROM_CONTENT', text: 'init'});
    tabURL = location.href;
    printWrap("reinitializing");
    if (tabURL.startsWith(playlistURL)) {
        playlistInit();
    }

    if (tabURL.startsWith(playerURL)) {
        playerInit();
    }

    if (tabURL.startsWith(songsURL)) {
        libraryInit();
    }
}

chrome.storage.local.get(["tracklistJSON"]).then((result) => {
    if (!result) {
        tracklist, taglist = importTags(result["tracklistJSON"]);
    }
});

//  Listen for calls from injected scripts
window.addEventListener("message", (event) => {
    var port = chrome.runtime.connect();
    // We only accept messages from ourselves
    if (event.source !== window) {
        return;
    }
    if (event.data.type && (event.data.type === "FROM_PAGE")) {
        printWrap("Content script received: " + event.data.text + event.data.type);

        //  Data Management
        if (event.data.text === "save") {
            let temp = false;
            chrome.storage.local.get(["tracklistJSON"]).then((result) => {
                if (event.data.tracklistJSON == result.tracklistJSON) {
                    alert("No changes to save.");
                } else {
                    chrome.storage.local.set({"tracklistJSON" : event.data.tracklistJSON}).then(() => {
                        alert("Data saved!");
                    });
                }
            });
            
        }

        if (event.data.text === "load") {
            chrome.storage.local.get(["tracklistJSON"]).then((result) => {
                window.postMessage(
                    {type : "FROM_CONTENT", text : "loaded", tracklistJSON : result.tracklistJSON}, "*");
            });
        }

        // if (event.data.text === "import") {
            
        // }
        // if (event.data.text === "export") {
            
        // }

        if (event.data.text === "clear") {
            chrome.storage.local.get(["tracklistJSON"]).then((result) => {
                chrome.storage.local.clear();
                chrome.storage.local.set({"tracklistJSON" : "{}"}).then(() => {
                    alert("Data cleared!")
                });
            });
        }

        //  MediaStream manipulation
        if (event.data.text === "skip") {
            var nextButton = document.getElementsByClassName("next-button")[0];
            if (nextButton) {
                nextButton.click();
                window.postMessage(
                    {type : "FROM_CONTENT", text : "skipped"}, "*");
            }
            // var stream = chrome.tabCapture.capture(audio = true, video = false);
            // printWrap(stream.getAudioTracks());
        }

        if (event.data.text == "export") {
            chrome.runtime.sendMessage({ type: 'FROM_CONTENT', text: 'export', tracklistJSON: event.data.tracklistJSON});
        }
        
        port.postMessage(event.data.text);
    }
    
}, false);

//  Listen for calls from service worker
chrome.runtime.onMessage.addListener((message, callback) => {
    printWrap("attempting to add listener");
    if (message.type === "FROM_WORKER") {
        if (message.text === "pageUpdate") {
            let newURL = message.url;
            let oldURL = currentTabURL;
            if (!(newURL.startsWith(playerURL) && oldURL.startsWith(playerURL))) {
                reInit();
            } else {
                window.postMessage(
                    {type : "FROM_CONTENT", text : "skipped"}, "*");
            }
            currentTabURL = newURL;
        }
    }
});

//  Adds "Data" modal button at the navbar
function navbarInit() {
    //  Add button that adds tracks when clicked
    var newElement = document.createElement("ytmusic-pivot-bar-item-renderer");
    newElement.className = "style-scope ytmusic-pivot-bar-renderer";
    newElement.role="tab";
    newElement.id="dataManagement";
    newElement.style="";
    newElement.setAttribute("onclick", "openDataModal()");
    var navbarMenu = document.querySelector('ytmusic-pivot-bar-renderer');
    navbarMenu.appendChild(newElement);
    var navbarTab = document.getElementById("dataManagement");
    printWrap(navbarTab);
    navbarTab.innerHTML=`
        <yt-formatted-string class="tab-title style-scope ytmusic-pivot-bar-item-renderer">
            <yt-attributed-string class="style-scope yt-formatted-string">Tags</yt-attributed-string>
        </yt-formatted-string>

    `;
    var string = navbarTab.querySelector('yt-formatted-string');
    string.removeAttribute("is-empty");
    var attr_string = string.querySelector('yt-attributed-string');
    attr_string.innerHTML='Tags';
    attr_string.id = "tagPlayHeaderButton";

    var dataModal = document.createElement("div");
    dataModal.innerHTML=`
        <div id="dataModal" class="modal" style="z-index=1;">
            <div class="modal-content">
                <span class="close" onclick="closeDataModal()">&times;</span>
                
                <h1 style="overflow: hidden; color: #F9E79F; font-size: 24pt;">Tag Data Management</h1><br><br>

                <div id="tagContainer-dataModal" class="tagContainer-dataModal">
                    
                    <!-- save -->
                    <button onclick="saveLibrary(tracklist, taglist)" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled" aria-label="Save Tags" style="">
                        <div class="cbox yt-spec-button-shape-next--button-text-content">
                            <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">Save Tags</span>
                        </div>
                        <yt-touch-feedback-shape style="border-radius: inherit;">
                            <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                                <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                                <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                            </div>
                        </yt-touch-feedback-shape>
                    </button>
                    
                    <!-- load -->
                    <button onclick="loadLibrary()" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled " aria-label="Load Tags" style="">
                        <div class="cbox yt-spec-button-shape-next--button-text-content">
                            <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">Load Tags</span>
                        </div>
                        <yt-touch-feedback-shape style="border-radius: inherit;">
                            <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                                <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                                <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                            </div>
                        </yt-touch-feedback-shape>
                    </button>

                    <!-- export -->
                    <button onclick="exportLibrary(tracklist)" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled " aria-label="Export Tags" style="">
                        <div class="cbox yt-spec-button-shape-next--button-text-content">
                            <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">Export Tags</span>
                        </div>
                        <yt-touch-feedback-shape style="border-radius: inherit;">
                            <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                                <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                                <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                            </div>
                        </yt-touch-feedback-shape>
                    </button>

                    <!-- import -->
                    <button onclick="importLibrary()" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled " aria-label="Import Tags" style="">
                        <div class="cbox yt-spec-button-shape-next--button-text-content">
                            <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">Import Tags</span>
                        </div>
                        <yt-touch-feedback-shape style="border-radius: inherit;">
                            <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                                <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                                <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                            </div>
                        </yt-touch-feedback-shape>
                    </button>

                    <!-- clear -->
                    <button onclick="clearLibrary()" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled " aria-label="Clear Tags" style="">
                        <div class="cbox yt-spec-button-shape-next--button-text-content">
                            <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">Clear Tags</span>
                        </div>
                        <yt-touch-feedback-shape style="border-radius: inherit;">
                            <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                                <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                                <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                            </div>
                        </yt-touch-feedback-shape>
                    </button>
                </div>
            </div>
        </div>
    `;

    if (tabURL.startsWith(playerURL)) {
        document.getElementById("player-page").appendChild(dataModal);
    } else {
        document.getElementsByTagName("body")[0].appendChild(dataModal);
    }
    var s = document.createElement('script');
    s.src = chrome.runtime.getURL('scripts/data.js');
    s.onload = function() {
        this.remove();
    };
    (document.head || document.documentElement).appendChild(s);

}

//  Initialize for playlist pages
function playlistInit() {

    var s = document.createElement('script');
    s.src = chrome.runtime.getURL('scripts/playlist.js');
    s.onload = function() {
        this.remove();
    };
    (document.head || document.documentElement).appendChild(s);
    
}

//  Initialize for player page
function playerInit() {
    var s = document.createElement('script');
    s.src = chrome.runtime.getURL('scripts/player.js');
    s.onload = function() {
        this.remove();
    };
    (document.head || document.documentElement).appendChild(s);
}

function libraryInit() {
    var s = document.createElement('script');
    s.src = chrome.runtime.getURL('scripts/library.js');
    s.onload = function() {
        this.remove();
    };
    (document.head || document.documentElement).appendChild(s);
}

//  Attache page update listener
function attachListener() {
    chrome.runtime.sendMessage(
        {type : "FROM_CONTENT", text : "listener"});
}

printWrap("We made it to ytmusic");

function printWrap(content) {
    if (debug) console.log(content);
}