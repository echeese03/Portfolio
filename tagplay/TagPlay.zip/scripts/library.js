//
var debug = false;
//

//  Global tracklist and taglist variables.
//      Object 'tracklist' acts as a dictionary where the keys are the ids of the tracks and the values are
//      dictionaries themselves with track properties as keys (title, artist, album, tags).
//
//      Set 'taglist' stores all tags across all songs.
var tracklist = {};
var taglist = new Set();
var selectlist = new Set();

var baseURL = "https://music.youtube.com/";
var baseLibraryURL = "https://music.youtube.com/library/songs";

var durationInSeconds = false;

//  Add reload tags button that adds new tracks to library when clicked
function init() {
    clearInterval(initialize);
    var playlistTrackContainers = document.querySelector('#header + #contents').querySelector('ytmusic-responsive-list-item-renderer');
    var shuffleTrackContainer = playlistTrackContainers;
    shuffleTrackContainer.setAttribute('num-flex-columns', '3');
    var shuffleButtonMenu = shuffleTrackContainer.querySelector("ytmusic-menu-renderer");
    shuffleButtonMenu.setAttribute('style', 'flex-grow: 3;');
    shuffleButtonMenu.classList.add("flex-columns");
    var buttonTagContainer = shuffleButtonMenu.querySelector("#top-level-buttons");
    var newElement = document.createElement("yt-button-renderer");
    newElement.className = "watch-button style-scope ytmusic-menu-renderer";
    buttonTagContainer.appendChild(newElement);
    var temp = buttonTagContainer.children
    var buttonShape = buttonTagContainer.querySelectorAll('yt-button-renderer')[temp.length-1].querySelector('yt-button-shape');
    buttonShape.innerHTML = `
        <button onclick = "loadTracks()" id = "loadTracks" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled "" aria-label="Reload Tags" style="">
            <div class="cbox yt-spec-button-shape-next--button-text-content">
                <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">Reload Tags</span>
            </div>
            <yt-touch-feedback-shape style="border-radius: inherit;">
                <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                    <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                    <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                </div>
            </yt-touch-feedback-shape>
        </button>
    `;
}

var initialize = setInterval(function () {
    var playlistTrackContainers = document.querySelector('#header + #contents').querySelector('ytmusic-responsive-list-item-renderer');
    if (playlistTrackContainers) {
        init();
    }
}, 1000);

//  Automatically load songs
window.postMessage(
    {type : "FROM_PAGE", text : "load"}, "*");

//  Autosave on exiting page DOESNT WORK
//
// window.addEventListener("beforeunload", save());

// function save() {
//     printWrap("saving");
//     var jsonString = exportTags(tracklist);
//     window.postMessage(
//         {type : "FROM_PAGE", text : "save", tracklistJSON : jsonString}, "*");
//     return null;
// }

//  Listen for load signal from content.js
window.addEventListener("message", (event) => {
    // We only accept messages from ourselves
    if (event.source !== window) {
        return;
    }

    if (event.data.type && (event.data.type === "FROM_CONTENT")) {
        printWrap("Content script received: " + event.data.text);

        if (event.data.text === "loaded") {
            tracklist, taglist = importTags(event.data.tracklistJSON);
            refreshTagDisplay();
        }
    }
}, false);


//  Adds a track to global tracklist. Can input preset tags.
function addTrack(id, title, artist, album, url, tags = new Set()) {
    if (id in tracklist) {
        printWrap("Track \"" + title + "\" already in tracklist; failed to add.");
        return false;
    }
    tracklist[id] = { "URL": url, "Title": title, "Artist": artist, "Album": album, "Tags": tags }
    addTag(id, artist);
    tags.forEach(taglist.add, taglist);
    printWrap("Added \"" + id + "\" and refreshed taglist.");
    return true;
}

//  Removes a track from global tracklist.
function removeTrack(id) {
    if (id in tracklist) {
        tags = new Set(tracklist[id]["Tags"]);
        delete tracklist[id];
        tags.forEach(element => {
            refreshTaglist(element);
        });
        return true;
    }
    printWrap("Track \"" + id + "\" does not exist in tracklist; failed to remove.")
    return false;
}

//  Adds specified tag to track and global taglist.
function addTag(id, tag) {
    tag = processString(tag);
    if (id in tracklist) {
        track = tracklist[id];
        tags = track["Tags"];
        if (tags.has(tag)) {
            printWrap("Track \"" + id + "\" already has tag \"" + tag + "\"; failed to add tag.");
            return false;
        }
        if (tag == "") {
            printWrap("Tag is empty.")
            return false;
        }
        tags.add(tag);
        taglist.add(tag);
        printWrap("Added tag \"" + tag + "\" to track.");
        return true;
    }
    printWrap("Track \"" + id + "\" does not exist; failed to add tag \"" + tag + "\".");
    return false;
}

//  Removes specified tag from track and runs refreshTaglist
function removeTag(id, tag) {
    if (id in tracklist) {
        track = tracklist[id];
        tags = track["Tags"];
        if (tags.has(tag)) {
            tags.delete(tag);
            printWrap("Removed \"" + tag + "\" from track.");
            refreshTaglist(tag);
            return true;
        }
        printWrap("Track \"" + id + "\" does not have tag \"" + tag + "\"; failed to remove tag.");
        return false;
    }
    printWrap("Track \"" + id + "\" does not exist; failed to remove tag \"" + tag + "\".");
    return false;
}

//  Checks global tracklist for remaining tracks with specified tag. If there are no more tracks
//  with specified tag, the tag is removed from global taglist.
function refreshTaglist(tag) {
    i = 0;
    for (let id in tracklist) {
        element = tracklist[id];
        i += element["Tags"].has(tag);
    }
    if (i > 0) {
        printWrap("There are still " + i + " tracks with tag \"" + tag + "\".");
        return false;
    }
    taglist.delete(tag);
    printWrap("\"" + tag + "\" was removed from global taglist because there are no more tracks with \"" + tag + "\".");
    return true;
}

//  Returns set of all track objects with the specified tags in 'tagset' parameter
function getTracksWithTag(tagset) {
    var tracksWithTag = new Set();
    var keys = Object.keys(tracklist);
    for (let i = 0; i < keys.length; i++) {
        var track = tracklist[keys[i]];
        // var trackKeys = Object.keys(track);
        isValid = true;
        tagset.forEach(tag => {
            if (isValid && !track["Tags"].has(tag)) {
                isValid = false;
            }
        });
        if (isValid) {
            tracksWithTag.add(track);
        }
    }
    return tracksWithTag;
}

function processString(str) {
    str = str.trim();
    str = str.replaceAll("\"", "");
    str = str.replaceAll("\'", "");
    str = str.replaceAll("_", " ");
    return str.replaceAll(".mp3", "");
}

// function convertDurationtoSeconds(duration) {
//     const hasHours = duration.split(':').length - 1 === 2;
//     if (hasHours) {
//         const [hours, minutes, seconds] = duration.split(':');
//         return 360 * Number(hours) + 60 + Number(minutes) + Number(seconds);
//     } else {
//         const [minutes, seconds] = duration.split(':');
//         return 60 * Number(minutes) + Number(seconds);
//     }
// };

function loadTracks() {
    var playlistTrackContainers = document.querySelector('#header + #contents').querySelectorAll('ytmusic-responsive-list-item-renderer');
    for(var i = 1; i < playlistTrackContainers.length ; i++) { 
        var trackContainer = playlistTrackContainers[i];
        var id = "";
        var url = "";
    
        var title = trackContainer.querySelector('.title-column');
        if(title !== null) {
            var atag = title.querySelector("a");
            if (atag !== null) {
                url = atag.href;
            }
            title = processString(title.textContent);
        } else return;
    
        var artist = trackContainer.querySelector('.secondary-flex-columns > yt-formatted-string:first-child');
        if(artist !== null) {
            artist = processString(artist.textContent);
        } else return;
    
        //  Finds duration of track
        // var duration = trackContainer.children[trackContainer.children.length - 1];
        // if(duration !== null) {
        //     duration = processString(duration.textContent);
        //     if (durationInSeconds) {
        //         duration = convertDurationtoSeconds(duration);
        //     }
        // }
    
        var album = trackContainer.querySelector('.secondary-flex-columns > yt-formatted-string:nth-child(2)');
        if(album !== null)
            album = processString(album.textContent);
        
        id = title + "_-_" + artist;
        temp = addTrack(id, title, artist, album, url);
        track = tracklist[id];
    }
    refreshTagDisplay();
}

function refreshTagDisplay() {
    refreshTaglist();
    var tracksToDisplay = getTracksWithTag(selectlist);
    var playlistTrackContainers = document.querySelector('#header + #contents').querySelectorAll('ytmusic-responsive-list-item-renderer');
    
    for(var i = 1; i < playlistTrackContainers.length ; i++) { 
        var trackContainer = playlistTrackContainers[i];
        var url = "";
        var id = "";
    
        var title = trackContainer.querySelector('.title-column');
        if(title !== null) {
            var atag = title.querySelector("a");
            if (atag !== null) {
                url = atag.href;
            } 
            title = processString(title.textContent);
        } else return;
    
        var artist = trackContainer.querySelector('.secondary-flex-columns > yt-formatted-string:first-child');
        if(artist !== null) {
            artist = processString(artist.textContent);
        } else return;
    
        var album = trackContainer.querySelector('.secondary-flex-columns > yt-formatted-string:nth-child(2)');
        if(album !== null)
            album = processString(album.textContent);
        
        id = title + "_-_" + artist;

        if (!tracklist[id]) {
            continue;
        }

        track = tracklist[id];
        tags = track["Tags"];

        var buttonMenu = trackContainer.querySelector('.ytmusic-menu-renderer');

        //  Clear existing tag buttons
        temp = buttonMenu.children.length
        for (j = 5; j < temp; j++) {
            buttonMenu.removeChild(buttonMenu.lastChild);
            printWrap("Cleared existing tag buttons for \"" + id + "\".");
        }



        if (selectlist.size > 0) {
            if (!tracksToDisplay.has(track)) {
                if (trackContainer.hasAttribute("is-checked")) {
                    trackContainer.querySelector("yt-checkbox-renderer").querySelector("yt-icon").click();
                }
                trackContainer.setAttribute('style',"display: none;");
            } else {
                trackContainer.setAttribute('style',"");
                if (!trackContainer.hasAttribute("is-checked")) {
                    trackContainer.querySelector("yt-checkbox-renderer").querySelector("yt-icon").click();
                }
            }
        } else {
            if (trackContainer.hasAttribute("is-checked")) {
                trackContainer.querySelector("yt-checkbox-renderer").querySelector("yt-icon").click();
            }
            trackContainer.setAttribute('style',"");
        }
        
        if (trackContainer.style != "display: none") {
            var remainingTags = new Set(tags);
            let k = 0;
            selectlist.forEach(tag => {
                if (tag != artist && k < 3) {
                    remainingTags.delete(tag);
                    k += 1;
                    var newElement = document.createElement("yt-button-renderer");
                    newElement.className = "watch-button style-scope ytmusic-menu-renderer"
                    newElement.id = "tag-" + url + "_" + tag;
                    newElement.style = "visibility: visible !important;"
                    
                    buttonMenu.appendChild(newElement);
                    var buttonShape = buttonMenu.querySelectorAll('yt-button-renderer')[k-1].querySelector('yt-button-shape');
                    var buttonType = "filled";
                    buttonShape.innerHTML = `
                        <button onclick="selectTag('${tag}')" class="yt-spec-button-shape-next yt-spec-button-shape-next--${buttonType} yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButton${buttonType}" aria-label="${tag}" style="">
                            <div class="cbox yt-spec-button-shape-next--button-text-content">
                                <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">${tag}</span>
                            </div>
                            <yt-touch-feedback-shape style="border-radius: inherit;">
                                <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                                    <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                                    <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                                </div>
                            </yt-touch-feedback-shape>
                        </button>
                    `;
                    if (debug) console.log("Added button \"" + url + "_" + tag + "\".");
                }
            });

            remainingTags.forEach(tag => {
                if (tag != artist && k < 3) {
                    k += 1;
                    var newElement = document.createElement("yt-button-renderer");
                    newElement.className = "watch-button style-scope ytmusic-menu-renderer"
                    newElement.id = "tag-" + url + "_" + tag;
                    newElement.style = "visibility: visible !important;"
                    
                    buttonMenu.appendChild(newElement);
                    var buttonShape = buttonMenu.querySelectorAll('yt-button-renderer')[k-1].querySelector('yt-button-shape');
                    var buttonType = "outline";
                    buttonShape.innerHTML = `
                        <button onclick="selectTag('${tag}')" class="yt-spec-button-shape-next yt-spec-button-shape-next--${buttonType} yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButton${buttonType}" aria-label="${tag}" style="">
                            <div class="cbox yt-spec-button-shape-next--button-text-content">
                                <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">${tag}</span>
                            </div>
                            <yt-touch-feedback-shape style="border-radius: inherit;">
                                <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                                    <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                                    <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                                </div>
                            </yt-touch-feedback-shape>
                        </button>
                    `;
                    if (debug) console.log("Added button \"" + url + "_" + tag + "\".");
                }
            });

            var newElement = document.createElement("yt-button-renderer");
            newElement.className = "watch-button style-scope ytmusic-menu-renderer"
            newElement.id = "edit-" + url;
            newElement.style = "visibility: visible !important;"
            
            buttonMenu.appendChild(newElement);
            temp = buttonMenu.querySelectorAll('yt-button-renderer');
            var buttonShape = temp[temp.length-1].querySelector('yt-button-shape');
            var modalID = "modal-" + url;

            buttonShape.innerHTML = `
                <button onclick = "openEditModal(\'${id}\', \'${modalID}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled "" aria-label="Edit Tags" style="">
                    <div class="cbox yt-spec-button-shape-next--button-text-content"
                        <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">EDIT</span>
                    </div>
                    <yt-touch-feedback-shape style="border-radius: inherit;">
                        <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response" aria-hidden="true">
                            <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                            <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                        </div>
                    </yt-touch-feedback-shape>
                </button>
                <div id="${modalID}" class="modal">
                    <div class="modal-content">
                        <span class="close" onclick="closeEditModal(\'${id}\', \'${modalID}\')">&times;</span>
                        <h1 style="overflow: hidden; color: #F9E79F;">${title}</h1><br>
                        <h3 style="overflow: hidden; color: #F9E79F;">${artist}</h3><br>
                        
                        <div id="addTagContainer-${modalID}" class = "addTagContainer-container">
                        </div>
                        
                        <br>
                        
                        <div id="tagContainer-${modalID}" class="tagContainer-container">
                        </div>
                    
                    </div>
                </div>
            `;
            printWrap("Added EDIT (tags) button for track \"" + id + "\".");
        }

    }

    //  Add buttons to top container
    var shuffleTrackContainer = playlistTrackContainers[0];
    shuffleTrackContainer.setAttribute('num-flex-columns', '3');
    var shuffleButtonMenu = shuffleTrackContainer.querySelector("ytmusic-menu-renderer");
    shuffleButtonMenu.setAttribute('style', 'flex-grow: 3;');
    shuffleButtonMenu.classList.add("flex-columns");
    var buttonTagContainer = shuffleButtonMenu.querySelector("#top-level-buttons");

    //  Remove existing buttons
    var temp = buttonTagContainer.children.length;
    for (j = 1; j < temp; j++) {
        buttonTagContainer.removeChild(buttonTagContainer.lastChild);
        printWrap("Cleared existing buttons.");
    }

    let k = 0;
    var remainingTags = new Set(taglist);
    if (selectlist.size > 0) {
        selectlist.forEach(tag => {
            if (k < 3) {
                remainingTags.delete(tag);
                k += 1;
                var newElement = document.createElement("yt-button-renderer");
                newElement.className = "watch-button style-scope ytmusic-menu-renderer"
                newElement.id = "tag-" + url + "_" + tag;
                
                buttonTagContainer.appendChild(newElement);
                var buttonShape = buttonTagContainer.querySelectorAll('yt-button-renderer')[k-1].querySelector('yt-button-shape');
                var buttonType = "filled";
                buttonShape.innerHTML = `
                    <button onclick="selectTag('${tag}')" class="yt-spec-button-shape-next yt-spec-button-shape-next--${buttonType} yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButton${buttonType}" aria-label="${tag}" style="">
                        <div class="cbox yt-spec-button-shape-next--button-text-content">
                            <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">${tag}</span>
                        </div>
                        <yt-touch-feedback-shape style="border-radius: inherit;">
                            <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                                <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                                <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                            </div>
                        </yt-touch-feedback-shape>
                    </button>
                `;
                printWrap("Added button \"" + url + "_" + tag + "\".");
            }
        });
    }

    remainingTags.forEach(tag => {
        if (k < 3) {
            k += 1;
            var newElement = document.createElement("yt-button-renderer");
            newElement.className = "watch-button style-scope ytmusic-menu-renderer"
            newElement.id = "tag-" + url + "_" + tag;
            
            buttonTagContainer.appendChild(newElement);
            var buttonShape = buttonTagContainer.querySelectorAll('yt-button-renderer')[k-1].querySelector('yt-button-shape');
            var buttonType = "outline";
            buttonShape.innerHTML = `
                <button onclick="selectTag('${tag}')" class="yt-spec-button-shape-next yt-spec-button-shape-next--${buttonType} yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButton${buttonType}" aria-label="${tag}" style="">
                    <div class="cbox yt-spec-button-shape-next--button-text-content">
                        <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">${tag}</span>
                    </div>
                    <yt-touch-feedback-shape style="border-radius: inherit;">
                        <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                            <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                            <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                        </div>
                    </yt-touch-feedback-shape>
                </button>
            `;
            printWrap("Added button \"" + url + "_" + tag + "\".");
        }
    });

    var newElement = document.createElement("yt-button-renderer");
    newElement.className = "watch-button style-scope ytmusic-menu-renderer"
    newElement.id = "select-player";
    
    buttonTagContainer.appendChild(newElement);
    temp = buttonTagContainer.querySelectorAll('yt-button-renderer');
    var buttonShape = temp[temp.length-1].querySelector('yt-button-shape');
    var modalID = "modal-player";

    buttonShape.innerHTML = `
        <button onclick = "openSelectModal(\'${id}\', \'${modalID}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled "" aria-label="Select Tags" style="">
            <div class="cbox yt-spec-button-shape-next--button-text-content"
                <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">SELECT</span>
            </div>
            <yt-touch-feedback-shape style="border-radius: inherit;">
                <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response" aria-hidden="true">
                    <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                    <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                </div>
            </yt-touch-feedback-shape>
        </button>
    `;
    
    modal = document.createElement('div');
    modal.id = "modal-select-div";
    document.body.appendChild(modal);
    modal = document.getElementById("modal-select-div");
    modal.innerHTML = `
        <div id="${modalID}" class="modal">
            <div class="modal-content">
                <span class="close" onclick="closeSelectModal(\'${modalID}\')">&times;</span>
                <h1 style="overflow: hidden; color: #F9E79F;">Select Tags</h1><br>
                
                <div id="addFilterTagContainer-${modalID}" class = "addTagContainer-container">
                </div>
                
                <br>
                
                <div id="filterTagContainer-${modalID}" class="tagContainer-container">
                </div>
            
            </div>
        </div>
    `;

    printWrap("Added SELECT (tags) button.");

    var newElement = document.createElement("yt-button-renderer");
    newElement.className = "watch-button style-scope ytmusic-menu-renderer"

    buttonTagContainer.appendChild(newElement);
    temp = buttonTagContainer.querySelectorAll('yt-button-renderer');
    printWrap(temp.length);
    var buttonShape = temp[temp.length-1].querySelector('yt-button-shape');

    buttonShape.innerHTML = `
    <button onclick = "loadTracks()" id = "loadTracks" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled "" aria-label="Reload Tags" style="">
        <div class="cbox yt-spec-button-shape-next--button-text-content">
            <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">Reload Tags</span>
        </div>
        <yt-touch-feedback-shape style="border-radius: inherit;">
            <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
            </div>
        </yt-touch-feedback-shape>
    </button>
    `;
}

function selectTag(tag) {
    if (selectlist.has(tag)) {
        selectlist.delete(tag);
    } else {
        selectlist.add(tag);
    }
    refreshTagDisplay();
}

function modalAddTag(id, modalID) {
    var inputID = document.getElementById("addTag-" + modalID);
    tag = inputID.value;
    addTag(id, tag);
    refreshEditModal(id, modalID);
    inputID.value = "";
}

function modalRemoveTag(id, modalID, tag) {
    var track = tracklist[id],
        artist = track["Artist"];
    if (tag != artist) {
        removeTag(id, tag);
        refreshEditModal(id, modalID);
    }
}

function openSelectModal(id, modalID) {
    //Refresh Player Modal
    refreshSelectModal(modalID);
    document.getElementById(modalID).style.display = "block";
    document.addEventListener("keydown", escSelect);
    printWrap("Opened modal \"" + modalID + "\"");
}

function escSelect(e) {
    if((e.key=='Escape'||e.key=='Esc')) {
        closeSelectModal(id, modalID);
        document.removeEventListener("keydown", escSelect)
    }
}

function closeSelectModal(modalID) {
    var tagContainer = document.getElementById("filterTagContainer-" + modalID);
    tagContainer.innerHTML = "";
    // tagContainer = document.getElementById("skipTagContainer-" + modalID);
    // tagContainer.innerHTML = "";
    document.getElementById(modalID).style.display = "none";
    refreshTagDisplay();
    printWrap("Closed modal \"" + modalID + "\"");
}

function refreshSelectModal(modalID) {
    printWrap("refreshing player modal");
    var filterTagContainer = document.getElementById("filterTagContainer-" + modalID);
    filterTagContainer.innerHTML = "";
    printWrap("Cleared tags.");
    
    tags = new Set(taglist);
    var i = 0;
    tags.forEach(tag => {
        i++;
        var newElement = document.createElement("yt-button-renderer");
        newElement.className = "watch-button style-scope ytmusic-menu-renderer tag-item"
        filterTagContainer.appendChild(newElement);
        var buttonShape = filterTagContainer.querySelectorAll('yt-button-renderer')[i-1].querySelector('yt-button-shape');
        var buttonType = "outline";
        if (selectlist.has(tag)) {
            buttonType = "filled";
        }
        buttonShape.innerHTML = `
            <button onclick="modalSelectTag(\'${tag}\', \'${modalID}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--${buttonType} yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButton${buttonType}" aria-label="${tag}" style="">
                <div class="cbox yt-spec-button-shape-next--button-text-content">
                    <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">${tag}</span>
                </div>
                <yt-touch-feedback-shape style="border-radius: inherit;">
                    <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                        <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                        <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                    </div>
                </yt-touch-feedback-shape>
            </button>
        `;
    });

    var addFilterTagContainer = document.getElementById("addFilterTagContainer-" + modalID);
    addFilterTagContainer.innerHTML = `
        <iron-input slot="input" class="addTag-item input-element style-scope tp-yt-paper-input" maxlength="20">
            <input style="color: #F9E79F;" onclick="this.select()" id="addFilterTag-${modalID}" class="addTag-item style-scope tp-yt-paper-input" maxlength="20" type="text" value="" autocomplete="off" placeholder="New tag name">
        </iron-input>
        <button id="addFilterTagButton-${modalID}" onclick = "addFilterTag(\'${modalID}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled" aria-label="Add Tag">
            <div class="cbox yt-spec-button-shape-next--button-text-content"
                <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">SELECT</span>
            </div>
            <yt-touch-feedback-shape style="border-radius: inherit;">
                <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response" aria-hidden="true">
                    <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                    <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                </div>
            </yt-touch-feedback-shape>
        </button>
    `;
    var input = document.getElementById(`addFilterTag-${modalID}`);

    // Execute a function when the user presses a key on the keyboard
    input.addEventListener("keydown", function(event) {
    // If the user presses the "Enter" key on the keyboard
    if (event.key === "Enter") {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        document.getElementById(`addFilterTagButton-${modalID}`).click();
        document.getElementById(`addFilterTag-${modalID}`).focus();
    }
    });
}

function addFilterTag(modalID) {
    var inputID = document.getElementById("addFilterTag-" + modalID);
    tag = inputID.value;
    if(selectableTags.has(tag)) {
        modalSelectTag(tag, modalID);
        inputID.value = "";
    } else {
        alert("Tag does not exist in queue; cannot select tag.");
    }
}

function modalSelectTag(tag, modalID) {
    if (selectlist.has(tag)) {
        selectlist.delete(tag);
    } else {
        selectlist.add(tag);
    }
    refreshSelectModal(modalID);
}

function refreshEditModal(id, modalID) {
    var tagContainer = document.getElementById("tagContainer-" + modalID);
    tagContainer.innerHTML = "";
    printWrap("Cleared tags.");
    
    var track = tracklist[id],
        title = track["Title"],
        artist = track["Artist"];
    
    //  Add tag buttons for track in modal
    track = tracklist[id];
    tags = track["Tags"];
    var i = 0;
    tags.forEach(tag => {
        if (i < 20) {
            i++;
            var newElement = document.createElement("yt-button-renderer");
            newElement.className = "watch-button style-scope ytmusic-menu-renderer tag-item"
            tagContainer.appendChild(newElement);
            var buttonShape = tagContainer.querySelectorAll('yt-button-renderer')[i-1].querySelector('yt-button-shape');
            buttonShape.innerHTML = `
                <button onclick="modalRemoveTag(\'${id}\', \'${modalID}'\, \'${tag}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled "" aria-label="${tag}" style="">
                    <div class="cbox yt-spec-button-shape-next--button-text-content">
                        <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">${tag}</span>
                    </div>
                    <yt-touch-feedback-shape style="border-radius: inherit;">
                        <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response-inverse" aria-hidden="true">
                            <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                            <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                        </div>
                    </yt-touch-feedback-shape>
                </button>
            `;
        }   
    });

    var addTagContainer = document.getElementById("addTagContainer-" + modalID);
    addTagContainer.innerHTML = `
        <iron-input slot="input" class="addTag-item input-element style-scope tp-yt-paper-input" maxlength="20">
            <input style="color: #F9E79F;" onclick="this.select()" id="addTag-${modalID}" class="addTag-item style-scope tp-yt-paper-input" maxlength="20" type="text" value="" autocomplete="off" placeholder="New tag name">
        </iron-input>
        <button id="addTagButton-${modalID}" onclick = "modalAddTag(\'${id}\', \'${modalID}\')" class="yt-spec-button-shape-next yt-spec-button-shape-next--filled yt-spec-button-shape-next--mono yt-spec-button-shape-next--size-m yt-spec-button-shape-next--icon-leading tagPlayButtonfilled "" aria-label="Add Tag">
            <div class="cbox yt-spec-button-shape-next--button-text-content"
                <span class="yt-core-attributed-string yt-core-attributed-string--white-space-no-wrap" role="text">ADD</span>
            </div>
            <yt-touch-feedback-shape style="border-radius: inherit;">
                <div class="yt-spec-touch-feedback-shape yt-spec-touch-feedback-shape--touch-response" aria-hidden="true">
                    <div class="yt-spec-touch-feedback-shape__stroke" style=""></div>
                    <div class="yt-spec-touch-feedback-shape__fill" style=""></div>
                </div>
            </yt-touch-feedback-shape>
        </button>
    `;
    var input = document.getElementById(`addTag-${modalID}`);

    // Execute a function when the user presses a key on the keyboard
    input.addEventListener("keydown", function(event) {
    // If the user presses the "Enter" key on the keyboard
    if (event.key === "Enter") {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        document.getElementById(`addTagButton-${modalID}`).click();
        document.getElementById(`addTag-${modalID}`).focus();
    }
    });



}

function openEditModal(id, modalID) {
    refreshEditModal(id, modalID);
    document.getElementById(modalID).style.display = "block";
    document.addEventListener("keydown", escEdit);
    printWrap("Opened modal \"" + modalID + "\"");
}

function escEdit(e) {
    if((e.key=='Escape'||e.key=='Esc')) {
        closeEditModal(id, modalID);
        document.removeEventListener("keydown", escEdit);
    }
}

function closeEditModal(id, modalID) {
    var tagContainer = document.getElementById("tagContainer-" + modalID);
    tagContainer.innerHTML = "";
    document.getElementById(modalID).style.display = "none";
    refreshTagDisplay();
    printWrap("Closed modal \"" + modalID + "\"");
}

function importTags(trackJSON) {
    taglist = new Set();
    tracklist = JSON.parse(trackJSON);
    var keys = Object.keys(tracklist)
    for (i = 0; i < keys.length; i++) {
        var track = tracklist[keys[i]];
        tags = new Set(track["Tags"]);
        track["Tags"] = tags;
        tags.forEach(taglist.add, taglist);
    }
    return (tracklist, taglist);
}

function printWrap(content) {
    if (debug) console.log(content);
}