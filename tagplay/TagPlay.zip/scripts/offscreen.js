// send a message every 40 sec to service worker
setInterval(() => {
    chrome.runtime.sendMessage({ type: 'FROM_OFFSCREEN', text: 'keepAlive'});
}, 40000);