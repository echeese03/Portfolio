function openDataModal() {
    document.getElementById("dataModal").style.display = "block";
    console.log("Opened data modal");
}

function closeDataModal() {
    document.getElementById("dataModal").style.display = "none";
    console.log("Closed modal data modal");
}

//Data Functions
function loadLibrary() {
    console.log("sending LOAD message");
    window.postMessage(
        {type : "FROM_PAGE", text : "load"}, "*");
}

function saveLibrary(tracklist) {
    console.log("sending SAVE message");
    var jsonString = exportTags(tracklist)
    window.postMessage(
        {type : "FROM_PAGE", text : "save", tracklistJSON : jsonString}, "*");
}

function clearLibrary() {
    console.log("sending CLEAR message");
    window.postMessage(
        {type : "FROM_PAGE", text : "clear"}, "*");
}

function importLibrary() {
    console.log("not yet implemented");
}

function exportLibrary(tracklist) {
    var jsonString = exportTags(tracklist)
    window.postMessage(
        {type : "FROM_PAGE", text : "export", tracklistJSON: jsonString}, "*");
}

function exportTags(tracklist) {
    var keys = Object.keys(tracklist);
    var JSONOut = "{";
    for (let i = 0; i < keys.length; i++) {
        var track = tracklist[keys[i]];
        var trackKeys = Object.keys(track);
        var JSONOut1 = "{";
        for (let j = 0; j < trackKeys.length-1; j++) {
            var temp = track[trackKeys[j]]
            var val = temp;
            JSONOut1 = JSONOut1 + `"${trackKeys[j]}":"${val}",`;
        }
        var tagsJSON = '"Tags" : [';
        //  Song's tags
        var tags = Array.from(track["Tags"]);
        for (let k = 0; k < tags.length-1; k++) {
            tagsJSON = tagsJSON + `"${tags[k]}",`;
        }
        tagsJSON = tagsJSON + `"${tags[tags.length-1]}"]`;

        JSONOut1 = JSONOut1 + `${tagsJSON}}`;
        JSONOut = JSONOut + `"${keys[i]}":${JSONOut1}`;
        if (i < keys.length-1) {
            JSONOut = JSONOut + ",";
        }
    }
    JSONOut = JSONOut.substring() + "}";
    return JSONOut;
}

function importTags(trackJSON) {
    taglist = new Set();
    tracklist = JSON.parse(trackJSON);
    var keys = Object.keys(tracklist)
    for (i = 0; i < keys.length; i++) {
        var track = tracklist[keys[i]];
        tags = new Set(track["Tags"]);
        track["Tags"] = tags;
        tags.forEach(taglist.add, taglist);
    }
    return (tracklist, taglist);
}

/**
 * Promisify a callback.
 * @param {Function} callback 
 * @returns {Promise}
 */
const toPromise = (callback) => {
    const promise = new Promise((resolve, reject) => {
        try {
            callback(resolve, reject);
        }
        catch (err) {
            reject(err);
        }
    });
    return promise;
}